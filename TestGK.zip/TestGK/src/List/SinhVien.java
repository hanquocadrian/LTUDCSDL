
package List;

public class SinhVien {
    private int ma;
    private String hoten, lop;
    private boolean phai; // true: nam, false: nu

    public SinhVien() {
        this(0,"","",true);
    }

    public SinhVien(int ma, String hoten, String lop, boolean phai) {
        this.ma = ma;
        this.hoten = hoten;
        this.lop = lop;
        this.phai = phai;
    }

    public int getMa() {
        return ma;
    }

    public void setMa(int ma) {
        this.ma = ma;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getLop() {
        return lop;
    }

    public void setLop(String lop) {
        this.lop = lop;
    }

    public boolean isPhai() {
        return phai;
    }

    public void setPhai(boolean phai) {
        this.phai = phai;
    }

    @Override
    public String toString() {
        return "Mã: " + ma + " - Tên: " + hoten + " - Lớp: " + lop + " - Phái: " + (phai?"Nam":"Nữ");
    }
}
