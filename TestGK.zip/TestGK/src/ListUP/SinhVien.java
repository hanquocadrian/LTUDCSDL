
package ListUP;

import List.*;

public class SinhVien {
    private int ma;
    private String hoten;
    private Lop lop;
    private boolean phai; // true: nam, false: nu

    public SinhVien() {
        this(0,"",new Lop(),true);
    }

    public SinhVien(int ma, String hoten, Lop lop, boolean phai) {
        this.ma = ma;
        this.hoten = hoten;
        this.lop = lop;
        this.phai = phai;
    }

    public int getMa() {
        return ma;
    }

    public void setMa(int ma) {
        this.ma = ma;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public Lop getLop() {
        return lop;
    }

    public void setLop(Lop lop) {
        this.lop = lop;
    }

    public boolean isPhai() {
        return phai;
    }

    public void setPhai(boolean phai) {
        this.phai = phai;
    }
    
    @Override
    public String toString() {
        return "Mã: " + getMa() + " - Tên: " + getHoten() + " - Lớp: " + getLop().getMa() + " - Phái: " + (isPhai()?"Nam":"Nữ");
    }
}
