
package QuanLy;

import java.util.ArrayList;

public class FakeData {
    public static ArrayList<NhanVien> ArrNV = new ArrayList<>();
    public static ArrayList<PhongBan> ArrPB = new ArrayList<>();
}
