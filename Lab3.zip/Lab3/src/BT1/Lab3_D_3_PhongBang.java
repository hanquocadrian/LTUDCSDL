
package BT1;

import java.util.ArrayList;
import java.util.List;

public class Lab3_D_3_PhongBang {
    private int mapb;
    private String tenphong;
    private List<Lab3_D_3_NhanVien> arrnv;

    public Lab3_D_3_PhongBang() {
        this(-1,"",new ArrayList<>());
    }

    public Lab3_D_3_PhongBang(int mapb, String tenphong, List<Lab3_D_3_NhanVien> arrnv) {
        this.mapb = mapb;
        this.tenphong = tenphong;
        this.arrnv = arrnv;
    }

    public int getMapb() {
        return mapb;
    }

    public void setMapb(int mapb) {
        this.mapb = mapb;
    }

    public String getTenphong() {
        return tenphong;
    }

    public void setTenphong(String tenphong) {
        this.tenphong = tenphong;
    }

    public List<Lab3_D_3_NhanVien> getArrnv() {
        return arrnv;
    }

    public void setArrnv(List<Lab3_D_3_NhanVien> arrnv) {
        this.arrnv = arrnv;
    }

    @Override
    public String toString() {
        return mapb + "/ " + tenphong;
    }
    
    
}
