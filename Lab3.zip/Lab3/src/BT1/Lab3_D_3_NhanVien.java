
package BT1;

public class Lab3_D_3_NhanVien {
    private int manv;
    private String hoten;
    private double luong;
    private Lab3_D_3_PhongBang phongban;

    public Lab3_D_3_NhanVien() {
        this(-1,"",0,new Lab3_D_3_PhongBang());
    }

    public Lab3_D_3_NhanVien(int manv, String hoten, double luong, Lab3_D_3_PhongBang phongban) {
        this.manv = manv;
        this.hoten = hoten;
        this.luong = luong;
        this.phongban = phongban;
    }

    public int getManv() {
        return manv;
    }

    public void setManv(int manv) {
        this.manv = manv;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public double getLuong() {
        return luong;
    }

    public void setLuong(double luong) {
        this.luong = luong;
    }

    public Lab3_D_3_PhongBang getPhongban() {
        return phongban;
    }

    public void setPhongban(Lab3_D_3_PhongBang phongban) {
        this.phongban = phongban;
    }

    @Override
    public String toString() {
        return "Lab3_D_3_NhanVien{" + "manv=" + manv + ", hoten=" + hoten + ", luong=" + luong + '}';
    }
}
