
package BT1;

public class HinhChuNhat {
    private double cd,cr;

    public HinhChuNhat() {
        this(1,1);
    }

    public HinhChuNhat(double cd, double cr) {
        this.cd = cd;
        this.cr = cr;
    }

    public double getCd() {
        return cd;
    }

    public void setCd(double cd) {
        this.cd = cd;
    }

    public double getCr() {
        return cr;
    }

    public void setCr(double cr) {
        this.cr = cr;
    }
    
    public double tinhDT(){
        return cd*cr;
    }
    
    public double tinhCV(){
        return (cd+cr)*2;
    }

    @Override
    public String toString() {
        return "CD=" + cd + "; CR=" + cr +"; DT=" + tinhDT() + "; CV=" + tinhCV()  ;
    }
    
    
}
