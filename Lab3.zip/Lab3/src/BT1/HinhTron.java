
package BT1;
public class HinhTron {
    private double r;

    public HinhTron() {
        this(1);
    }

    public HinhTron(double r) {
        this.r = r;
    }

    public double getR() {
        return r;
    }
    public void setR(double r) {
        this.r = r;
    }
    
    public double tinhDT(){
        return Math.PI * Math.pow(this.r, 2);
    }
    
    public double tinhCV(){
        return 2*Math.PI*this.r;
    }

    @Override
    public String toString() {
        return "R=" + r + ';'+"DT=" + tinhDT() + ';'+"CV=" + tinhCV();
    }
    
    
}
