
package BT1;

import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.table.DefaultTableModel;

public class Lab3_BTLT_3 extends javax.swing.JFrame {
    DefaultListModel modelListPB = null;
    List<Lab3_D_3_NhanVien> dsNV = null;
    DefaultTableModel modelTableNV = null;

    private void AutoAddPB(){
        List<Lab3_D_3_NhanVien> arrnv1 = new ArrayList<>();
        Lab3_D_3_PhongBang pb1 = new Lab3_D_3_PhongBang(1, "CNTT", arrnv1);
        modelListPB.addElement(pb1);
        
        dsNV = pb1.getArrnv();
            
        int manv = 1;
        String hoten = "Duc";
        double luong = 2000;
        Lab3_D_3_NhanVien nv = new Lab3_D_3_NhanVien(manv,hoten,luong,pb1);

        dsNV.add(nv);
        pb1.setArrnv(dsNV);
                
        List<Lab3_D_3_NhanVien> arrnv2 = new ArrayList<>();
        Lab3_D_3_PhongBang pb2 = new Lab3_D_3_PhongBang(2, "QTKD", arrnv2);
        modelListPB.addElement(pb2); 
        
        List<Lab3_D_3_NhanVien> arrnv3 = new ArrayList<>();
        Lab3_D_3_PhongBang pb3 = new Lab3_D_3_PhongBang(3, "KTCT", arrnv3);
        modelListPB.addElement(pb3);
        
        ConvertListToTableModel(pb1.getArrnv());
    }
    
    private void ConvertListToTableModel(List<Lab3_D_3_NhanVien> dsNV){
        modelTableNV.setRowCount(0);
        if(!dsNV.isEmpty()){
            for(Lab3_D_3_NhanVien nv : dsNV){
                modelTableNV.addRow(new Object[]{
                        nv.getManv(),
                        nv.getHoten(),
                        nv.getLuong()
                    }
                );
            }            
        }
    }
    
    public Lab3_BTLT_3() {
        initComponents();
        this.setLocationRelativeTo(null);
        
        modelListPB = (DefaultListModel) lstPB.getModel();
        dsNV = new ArrayList<>();
        modelTableNV = (DefaultTableModel) tblNVPB.getModel();
        
        AutoAddPB();
        lstPB.setSelectedIndex(0);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        lstPB = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblNVPB = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtManv = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtHoten = new javax.swing.JTextField();
        txtLuong = new javax.swing.JTextField();
        btnThem = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Lab3_BTLT_3");

        lstPB.setModel(new DefaultListModel());
        lstPB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lstPBMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(lstPB);

        tblNVPB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "MANV", "HO TEN", "LUONG"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblNVPB);

        jLabel1.setText("Manv: ");

        jLabel2.setText("Ho ten: ");

        jLabel3.setText("Luong: ");

        btnThem.setText("Them");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnXoa.setText("Xoa");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(159, 159, 159)
                .addComponent(btnThem)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnXoa)
                .addContainerGap(214, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtHoten)
                            .addComponent(txtLuong)
                            .addComponent(txtManv)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(159, 159, 159)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 278, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtManv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtHoten, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnThem)
                            .addComponent(btnXoa))))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lstPBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lstPBMouseClicked
        int index = lstPB.getSelectedIndex();
        if (index>=0){
            Lab3_D_3_PhongBang pb = (Lab3_D_3_PhongBang) modelListPB.getElementAt(index);
            ConvertListToTableModel(pb.getArrnv());
        }        
    }//GEN-LAST:event_lstPBMouseClicked

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        int index = lstPB.getSelectedIndex();
        if (index>=0){
            Lab3_D_3_PhongBang pb = (Lab3_D_3_PhongBang) modelListPB.getElementAt(index);
            
            dsNV = pb.getArrnv();
            
            int manv = Integer.parseInt(txtManv.getText());
            String hoten = txtHoten.getText();
            double luong = Double.parseDouble(txtLuong.getText());
            Lab3_D_3_NhanVien nv = new Lab3_D_3_NhanVien(manv,hoten,luong,pb);
            
            dsNV.add(nv);
            pb.setArrnv(dsNV);
            ConvertListToTableModel(pb.getArrnv());
            
            txtManv.setText("");
            txtHoten.setText("");
            txtLuong.setText("");
        }         
    }//GEN-LAST:event_btnThemActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Lab3_BTLT_3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Lab3_BTLT_3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Lab3_BTLT_3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Lab3_BTLT_3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Lab3_BTLT_3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnXoa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JList<String> lstPB;
    private javax.swing.JTable tblNVPB;
    private javax.swing.JTextField txtHoten;
    private javax.swing.JTextField txtLuong;
    private javax.swing.JTextField txtManv;
    // End of variables declaration//GEN-END:variables
}
