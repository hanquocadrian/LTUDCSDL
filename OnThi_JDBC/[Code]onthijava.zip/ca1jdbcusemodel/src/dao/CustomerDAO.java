package dao;

import java.util.List;
import model.Customer;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import uti.ConnectionManager;

public class CustomerDAO {

    public List<Customer> findAll() {
        List<Customer> list = new ArrayList<Customer>();
        Connection con = ConnectionManager.getConnetion();
        try {
            Statement stm = con.createStatement();
            String sql = "select * from customer";
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                Customer c = new Customer();
                c.setId(rs.getInt(1));
                c.setName(rs.getString(2));
                c.setAge(rs.getInt(3));
                list.add(c);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;
    }
    public Customer findByID(int id) {
        Customer c = null;
        Connection con = ConnectionManager.getConnetion();
        try {
            PreparedStatement pstm = con.prepareStatement("select * from customer where id= ?");
            pstm.setInt(1, id);
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                c = new Customer();
                c.setId(rs.getInt("id"));
                c.setName(rs.getString("name"));
                c.setAge(rs.getInt("age"));
            }
        } catch (SQLException ex) {
            return null;
        }

        return c;
    }
    public boolean insert(Customer c) {
        Connection con = ConnectionManager.getConnetion();
        try {
            String sql = "insert into customer(name,age) values(?,?)";
            PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, c.getName());
            ps.setInt(2, c.getAge());

            int i = ps.executeUpdate();

            if (i != 0) {
                ResultSet keyResultSet = ps.getGeneratedKeys();
                int newCustomerId = 0;
                if (keyResultSet.next()) {
                    newCustomerId = (int) keyResultSet.getInt(1);
                    c.setId(newCustomerId);
                }
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }
    public boolean delete(int id) {
        boolean result = true;
        Connection con = ConnectionManager.getConnetion();
        try {
            PreparedStatement pstm = con.prepareStatement("delete from customer where id=?");
            pstm.setInt(1, id);
            result = pstm.executeUpdate() > 0;
        } catch (Exception e) {
            return false;
        }
        return result;

    }
    public boolean upadte(Customer c) {
        boolean result = true;
        Connection con = ConnectionManager.getConnetion();
        try {
            PreparedStatement pstm = con.prepareStatement("update customer set name=?,age=? where id=? ");
            pstm.setString(1, c.getName());
            pstm.setInt(2, c.getAge());
            pstm.setInt(3, c.getId());
            result = pstm.executeUpdate() > 0;
        } catch (Exception e) {
            return false;
        }
        return result;
    }
    
}
