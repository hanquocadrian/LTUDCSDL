
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Account;
import uti.ConnectionManager;

public class AccountDAO {
    public List<Account> findAll() {
        List<Account> list = new ArrayList<Account>();
        Connection con = ConnectionManager.getConnetion();
        CustomerDAO dao=new CustomerDAO();
        try {
            Statement stm = con.createStatement();
            String sql = "select * from account";
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                Account acc = new Account();
                acc.setId(rs.getInt(1));
                acc.setBalance(rs.getInt(2));
                acc.setCreateDate(rs.getDate(3));
                acc.setStatus(rs.getBoolean(4));
                acc.setCus(dao.findByID(rs.getInt(5)));
                list.add(acc);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;
    }
    public List<Account> findAllByID(int idcus) {
        List<Account> list = new ArrayList<Account>();
        Connection con = ConnectionManager.getConnetion();
        CustomerDAO dao=new CustomerDAO();
        try {
            
            PreparedStatement pst=con.prepareStatement("select * from account where idcus=?");
            pst.setInt(1,idcus);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Account acc = new Account();
                acc.setId(rs.getInt(1));
                acc.setBalance(rs.getInt(2));
                acc.setCreateDate(rs.getDate(3));
                acc.setStatus(rs.getBoolean(4));
                acc.setCus(dao.findByID(rs.getInt(5)));
                list.add(acc);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;
    }
    public boolean insert(Account acc) {
        Connection con = ConnectionManager.getConnetion();
        try {
            String sql = "insert into account(balance,createdate,status,idcus) values(?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, acc.getBalance());
            ps.setDate(2, new java.sql.Date(acc.getCreateDate().getTime()));
            ps.setBoolean(3, acc.isStatus());
            ps.setInt(4, acc.getCus().getId());
            int i = ps.executeUpdate();

            if (i != 0) {
                ResultSet keyResultSet = ps.getGeneratedKeys();
                int newAccountId = 0;
                if (keyResultSet.next()) {
                    newAccountId = (int) keyResultSet.getInt(1);
                    acc.setId(newAccountId);
                }
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AccountDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return false;
    }
    public boolean delete(int id) {
        boolean result = true;
        Connection con = ConnectionManager.getConnetion();
        try {
            PreparedStatement pstm = con.prepareStatement("delete from account where id=?");
            pstm.setInt(1, id);
            result = pstm.executeUpdate() > 0;
        } catch (Exception e) {
            return false;
        }
        return result;

    }
    public boolean upadte(Account acc) {
        boolean result = true;
        Connection con = ConnectionManager.getConnetion();
        try {
            PreparedStatement pstm = con.prepareStatement("update account set balance=?,createdate=?,status=?,idcus=? where id=? ");
            pstm.setInt(1, acc.getBalance());
            pstm.setDate(2, new java.sql.Date(acc.getCreateDate().getTime()));
            pstm.setBoolean(3, acc.isStatus());
            pstm.setInt(4, acc.getCus().getId());
            pstm.setInt(5,acc.getId());
            result = pstm.executeUpdate() > 0;
        } catch (Exception e) {
            return false;
        }
        return result;
    }
    public Account findByID(int id) {
        Account acc = null;
        Connection con = ConnectionManager.getConnetion();
        try {
            PreparedStatement pstm = con.prepareStatement("select * from account where id= ?");
            pstm.setInt(1, id);
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                acc = new Account();
                acc.setId(rs.getInt(1));
                acc.setBalance(rs.getInt(2));
                acc.setCreateDate(rs.getDate(3));
                acc.setStatus(rs.getBoolean(4));
                CustomerDAO dao=new CustomerDAO();
                acc.setCus(dao.findByID(rs.getInt(5)));
            }
        } catch (SQLException ex) {
            return null;
        }

        return acc;
    }
}
