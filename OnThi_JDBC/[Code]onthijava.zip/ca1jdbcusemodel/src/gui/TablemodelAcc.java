package gui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;
import model.Account;

public class TablemodelAcc<E> extends AbstractTableModel {

    protected List<E> list;

    protected String[] FIELD_NAMES = {};

    public String[] getFIELD_NAMES() {
        return FIELD_NAMES;
    }

    public void setFIELD_NAMES(String[] FIELD_NAMES) {
        this.FIELD_NAMES = FIELD_NAMES;
    }

    public TablemodelAcc(List<E> list, String[] fIELD_NAMES) {
        super();
        this.list = list;
        FIELD_NAMES = fIELD_NAMES;
    }

    public TablemodelAcc() {
        super();
        list = new ArrayList<E>(); // to avoid NullPointer

    }

    public String getColumnName(int column) {
        if (column < FIELD_NAMES.length) {
            return FIELD_NAMES[column];
        }
        return ""; // unknown column
    }

    public void remove(int row) {
        list.remove(list.get(row));
        fireTableDataChanged();
    }

    public void add(E c) {
        list.add(c);
        fireTableDataChanged();
    }

    public E get(int row) {
       
       return list.get(row);
    }

    public void set(int index, E e) {
        list.set(index, e);
        fireTableDataChanged();
    }

    @Override
    public int getColumnCount() {
        return FIELD_NAMES.length;
    }

    @Override
    public int getRowCount() {
        return list.size();
    }

    public void setlist(List<E> list) {
        assert list != null;
        this.list = list;
        fireTableDataChanged();
    }

    public List<E> getlist() {
        return list;
    }

    @Override
    public Object getValueAt(int row, int col) {
        if (row >= list.size()) {
            return "";
        }
        Account c = (Account) list.get(row);
        SimpleDateFormat df=new SimpleDateFormat("dd/MM/yyyy");
        switch (col) {  // trinh bay du lieu row.
            case 0:
                return c.getId();
            case 1:
                return c.getBalance();
            case 2:
                return df.format(c.getCreateDate());
            case 3:
                return c.isStatus()?"Active":"DeActive";
            case 4:
                return c.getCus();
            default:
                return "";
        }
    }

}
