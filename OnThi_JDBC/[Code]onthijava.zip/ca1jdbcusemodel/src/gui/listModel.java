
package gui;

import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractListModel;

public class listModel<E> extends AbstractListModel {

    private List<E> list;

    public listModel() {
        list = new ArrayList<E>();
    }

    public listModel(List<E> list) {
        this.list = list;
    }

    @Override
    public E getElementAt(int arg0) {
        // TODO Auto-generated method stub
        return list.get(arg0);
    }

    @Override
    public int getSize() {
        // TODO Auto-generated method stub
        return list.size();
    }

    public void setE(List<E> list) {
        assert list != null;
        this.list = list;
        fireContentsChanged(this, 0, 1);
    }

    public void set(int index, E element) {
        list.set(index, element);
        fireContentsChanged(this, 0,1);
    }

    public void remove(int index) {
        list.remove(index);
        fireContentsChanged(this, 0,1);
    }

    public void add(E e) {
        list.add(e);
        fireContentsChanged(this, 0,1);
    }

    public List<E> getList() {
        return list;
    }

    public void setList(List<E> list) {
        this.list = list;
    }
    
}
