package uti;

import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractListModel;
import javax.swing.ComboBoxModel;


public class CbxModel<E> extends AbstractListModel implements ComboBoxModel {

    protected List<E> list = new ArrayList<E>();
    E selection = null;

    public CbxModel(List<E> list) {
        this.list = list;
    }

    public CbxModel() {
    }

    @Override
    public E getElementAt(int index) {
        return list.get(index);
    }

    @Override
    public int getSize() {
        // TODO Auto-generated method stub
        return list.size();
    }

    @Override
    public E getSelectedItem() {
        // TODO Auto-generated method stub
        return selection;
    }

    @Override
    public void setSelectedItem(Object anItem) {
        selection = (E) anItem;
        fireContentsChanged(anItem, 0, 0);

    }

    public List<E> getList() {
        return list;
    }

    public void setList(List<E> list) {
        this.list = list;
        fireContentsChanged(this, 0, 0);
    }

    public void add(E e) {
        list.add(e);
        fireContentsChanged(e, 0, 0);
    }

    public void set(int index, E element) {
        list.set(index, element);
        fireContentsChanged(this, 0, 0);
    }

    public void add(int index, E element) {
        list.add(index, element);
        fireContentsChanged(this, 0, 0);
    }

    public void remove(int index) {
        list.remove(index);
        fireContentsChanged( this,0, 0);
    }
    public void remove(E element) {
        list.remove(element);
        fireContentsChanged( element,0, 0);
    }
    
    
}
