package model;

import java.util.Date;

public class Account {

    private int id;
    private int balance;
    private Date createDate;
    private boolean status;
    private Customer cus;
    public Account() {
    }
    public Account(int balance, Date createDate, boolean status, Customer cus) {
        this.balance = balance;
        this.createDate = createDate;
        this.status = status;
        this.cus = cus;
    }
    @Override
    public String toString() {
        return id + "--" + balance;
    }
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + this.id;
        return hash;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Account other = (Account) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
    public int getId() { return id;    }
    public void setId(int id) { this.id = id;    }
    public int getBalance() {
        return balance;
    }
    public void setBalance(int balance) {
        this.balance = balance;
    }
    public Date getCreateDate() {
        return createDate;
    }
    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }
    public boolean isStatus() {
        return status;
    }
    public void setStatus(boolean status) {
        this.status = status;
    }
    public Customer getCus() {
        return cus;
    }
    public void setCus(Customer cus) {
        this.cus = cus;
    }

}
