
package uti;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class ConnectionManager {
    public static Connection getConnetion(){
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/2020?useUnicode=true&characterEncoding=UTF-8","root","");
            return con;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConnectionManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConnectionManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
        
    }
}
